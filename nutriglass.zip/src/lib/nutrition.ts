export type Gender = "male" | "female";
export type Activity = "sedentary" | "light" | "moderate" | "veryActive" | "extraActive";
export type Goal = "lose" | "maintain" | "gain";

export const activityMultipliers: Record<Activity, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  veryActive: 1.725,
  extraActive: 1.9,
};

export const goalAdjustments: Record<Goal, number> = {
  lose: -500,
  maintain: 0,
  gain: 300,
};

export interface Profile {
  gender: Gender;
  age: number;
  weight: number; // kg
  height: number; // cm
  activity: Activity;
  goal: Goal;
}

export interface NutritionResult {
  bmr: number;
  tdee: number;
  target: number;
  proteinG: number;
  carbsG: number;
  fatsG: number;
}

// Mifflin-St Jeor
export function calculate(p: Profile): NutritionResult {
  const base = 10 * p.weight + 6.25 * p.height - 5 * p.age;
  const bmr = p.gender === "male" ? base + 5 : base - 161;
  const tdee = bmr * activityMultipliers[p.activity];
  const target = tdee + goalAdjustments[p.goal];

  // Macro splits by goal
  const split =
    p.goal === "lose"
      ? { p: 0.35, c: 0.35, f: 0.3 }
      : p.goal === "gain"
      ? { p: 0.3, c: 0.45, f: 0.25 }
      : { p: 0.3, c: 0.4, f: 0.3 };

  const proteinG = (target * split.p) / 4;
  const carbsG = (target * split.c) / 4;
  const fatsG = (target * split.f) / 9;

  return {
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    target: Math.round(target),
    proteinG: Math.round(proteinG),
    carbsG: Math.round(carbsG),
    fatsG: Math.round(fatsG),
  };
}
