import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { translations, langOrder, langShort, type Lang } from "@/lib/i18n";
import {
  calculate,
  type Activity,
  type Gender,
  type Goal,
  type Profile,
} from "@/lib/nutrition";
import {
  Activity as ActivityIcon,
  Apple,
  Flame,
  History,
  Leaf,
  Moon,
  Plus,
  Save,
  Sun,
  Target,
  Trash2,
  User,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

interface FoodItem {
  id: string;
  name: string;
  calories: number;
}

interface HistoryEntry {
  id: string;
  date: string;
  target: number;
  proteinG: number;
  carbsG: number;
  fatsG: number;
}

type Theme = "dark" | "light";

function Index() {
  const [lang, setLang] = useState<Lang>("en");
  const t = translations[lang];
  const dir = lang === "ar" ? "rtl" : "ltr";

  const [theme, setTheme] = useState<Theme>("dark");
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const savedTheme = (localStorage.getItem("nutriglass-theme") as Theme | null) ?? "dark";
      setTheme(savedTheme);
      const savedHist = localStorage.getItem("nutriglass-history");
      if (savedHist) setHistory(JSON.parse(savedHist));
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "light") root.classList.add("light");
    else root.classList.remove("light");
    try {
      localStorage.setItem("nutriglass-theme", theme);
    } catch {}
  }, [theme]);

  const [profile, setProfile] = useState<Profile>({
    gender: "male",
    age: 28,
    weight: 75,
    height: 178,
    activity: "moderate",
    goal: "maintain",
  });

  const result = useMemo(() => calculate(profile), [profile]);

  const [foods, setFoods] = useState<FoodItem[]>([]);
  const [foodName, setFoodName] = useState("");
  const [foodCal, setFoodCal] = useState("");
  const [foodErr, setFoodErr] = useState<"name" | "cal" | null>(null);
  const [shakeKey, setShakeKey] = useState(0);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem("nutriglass-history", JSON.stringify(history));
    } catch {}
  }, [history, hydrated]);

  const consumed = foods.reduce((s, f) => s + f.calories, 0);
  const remaining = result.target - consumed;
  const progressPct = Math.min(100, (consumed / result.target) * 100);

  const activities: Activity[] = ["sedentary", "light", "moderate", "veryActive", "extraActive"];
  const goals: Goal[] = ["lose", "maintain", "gain"];

  const dateLocale = lang === "ar" ? "ar-EG" : lang === "fr" ? "fr-FR" : "en-US";

  function addFood() {
    const name = foodName.trim();
    const cal = parseInt(foodCal, 10);
    if (!name) {
      setFoodErr("name");
      setShakeKey((k) => k + 1);
      return;
    }
    if (!Number.isFinite(cal) || cal <= 0 || cal > 5000) {
      setFoodErr("cal");
      setShakeKey((k) => k + 1);
      return;
    }
    setFoodErr(null);
    setFoods((f) => [...f, { id: crypto.randomUUID(), name, calories: cal }]);
    setFoodName("");
    setFoodCal("");
  }

  function saveResult() {
    const entry: HistoryEntry = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      target: result.target,
      proteinG: result.proteinG,
      carbsG: result.carbsG,
      fatsG: result.fatsG,
    };
    setHistory((h) => [entry, ...h].slice(0, 30));
  }

  return (
    <div dir={dir} className="min-h-screen px-4 py-8 sm:px-6 lg:px-10">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <header className="mb-10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="glass-strong grid h-12 w-12 shrink-0 place-items-center rounded-2xl">
              <Leaf className="h-6 w-6 text-primary" />
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-2xl font-bold text-gradient sm:text-3xl">
                {t.appName}
              </h1>
              <p className="truncate text-xs text-muted-foreground sm:text-sm">{t.tagline}</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="glass grid h-10 w-10 place-items-center rounded-full text-foreground transition hover:text-primary"
              aria-label={theme === "dark" ? t.lightMode : t.darkMode}
              title={theme === "dark" ? t.lightMode : t.darkMode}
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <div className="glass flex items-center gap-1 rounded-full p-1">
              {langOrder.map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`rounded-full px-3 py-1.5 text-xs font-bold transition ${
                    lang === l
                      ? "bg-primary text-primary-foreground shadow-[var(--shadow-glow)]"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  aria-label={translations[l].langLabel}
                >
                  {langShort[l]}
                </button>
              ))}
            </div>
          </div>
        </header>

        {/* Hero */}
        <section className="mb-10 text-center">
          <h2 className="mx-auto max-w-3xl text-4xl font-extrabold leading-tight sm:text-5xl md:text-6xl">
            <span className="text-gradient">{t.tagline}</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground sm:text-lg">
            {t.subtitle}
          </p>
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Profile */}
          <Card icon={<User className="h-5 w-5" />} title={t.profile} desc={t.profileDesc}>
            <div className="space-y-5">
              <div>
                <Label>{t.gender}</Label>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {(["male", "female"] as Gender[]).map((g) => (
                    <PillButton
                      key={g}
                      active={profile.gender === g}
                      onClick={() => setProfile({ ...profile, gender: g })}
                    >
                      {t[g]}
                    </PillButton>
                  ))}
                </div>
              </div>

              <NumberField
                label={t.age}
                unit={t.years}
                value={profile.age}
                onChange={(v) => setProfile({ ...profile, age: v })}
                min={10}
                max={100}
              />
              <NumberField
                label={t.weight}
                unit={t.kg}
                value={profile.weight}
                onChange={(v) => setProfile({ ...profile, weight: v })}
                min={30}
                max={250}
              />
              <NumberField
                label={t.height}
                unit={t.cm}
                value={profile.height}
                onChange={(v) => setProfile({ ...profile, height: v })}
                min={100}
                max={230}
              />
            </div>
          </Card>

          {/* Activity + Goal */}
          <div className="space-y-6 lg:col-span-2">
            <Card icon={<ActivityIcon className="h-5 w-5" />} title={t.activity} desc={t.activityDesc}>
              <div className="grid gap-2 sm:grid-cols-2">
                {activities.map((a) => (
                  <SelectRow
                    key={a}
                    active={profile.activity === a}
                    onClick={() => setProfile({ ...profile, activity: a })}
                    title={t[a]}
                    desc={t[`${a}Desc` as keyof typeof t] as string}
                  />
                ))}
              </div>
            </Card>

            <Card icon={<Target className="h-5 w-5" />} title={t.goal} desc={t.goalDesc}>
              <div className="grid gap-2 sm:grid-cols-3">
                {goals.map((g) => (
                  <SelectRow
                    key={g}
                    active={profile.goal === g}
                    onClick={() => setProfile({ ...profile, goal: g })}
                    title={t[g]}
                    desc={t[`${g}Desc` as keyof typeof t] as string}
                  />
                ))}
              </div>
            </Card>
          </div>
        </div>

        {/* Results */}
        <section className="mt-8">
          <Card icon={<Flame className="h-5 w-5" />} title={t.results} desc="">
            <div className="grid gap-4 sm:grid-cols-3">
              <Stat label={t.bmr} value={result.bmr} unit="kcal" />
              <Stat label={t.tdee} value={result.tdee} unit="kcal" />
              <Stat label={t.targetCalories} value={result.target} unit="kcal" highlight />
            </div>

            <div className="mt-6">
              <h4 className="mb-3 text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                {t.macros}
              </h4>
              <div className="grid gap-3 sm:grid-cols-3">
                <MacroBar label={t.protein} grams={result.proteinG} unit={t.grams} color="oklch(0.78 0.16 160)" total={result.proteinG + result.carbsG + result.fatsG} />
                <MacroBar label={t.carbs} grams={result.carbsG} unit={t.grams} color="oklch(0.72 0.18 175)" total={result.proteinG + result.carbsG + result.fatsG} />
                <MacroBar label={t.fats} grams={result.fatsG} unit={t.grams} color="oklch(0.85 0.14 155)" total={result.proteinG + result.carbsG + result.fatsG} />
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={saveResult}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:opacity-90"
              >
                <Save className="h-4 w-4" />
                {t.saveResult}
              </button>
            </div>
          </Card>
        </section>

        {/* History */}
        <section className="mt-8">
          <Card icon={<History className="h-5 w-5" />} title={t.history} desc={t.historyDesc}>
            {history.length === 0 ? (
              <p className="glass rounded-xl p-6 text-center text-sm text-muted-foreground">
                {t.historyEmpty}
              </p>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-start text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        <th className="px-3 py-2 text-start">{t.date}</th>
                        <th className="px-3 py-2 text-end">{t.targetCalories}</th>
                        <th className="px-3 py-2 text-end">{t.protein}</th>
                        <th className="px-3 py-2 text-end">{t.carbs}</th>
                        <th className="px-3 py-2 text-end">{t.fats}</th>
                        <th className="px-3 py-2"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {history.map((h) => (
                        <tr key={h.id} className="glass animate-fade-in rounded-xl">
                          <td className="px-3 py-3 text-start font-medium">
                            {new Date(h.date).toLocaleString(dateLocale, {
                              dateStyle: "short",
                              timeStyle: "short",
                            })}
                          </td>
                          <td className="px-3 py-3 text-end font-bold text-primary">
                            {h.target}
                          </td>
                          <td className="px-3 py-3 text-end">{h.proteinG}{t.grams}</td>
                          <td className="px-3 py-3 text-end">{h.carbsG}{t.grams}</td>
                          <td className="px-3 py-3 text-end">{h.fatsG}{t.grams}</td>
                          <td className="px-3 py-3 text-end">
                            <button
                              onClick={() =>
                                setHistory((arr) => arr.filter((x) => x.id !== h.id))
                              }
                              className="rounded-lg p-2 text-muted-foreground transition hover:bg-destructive/20 hover:text-destructive"
                              aria-label={t.remove}
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 flex justify-end">
                  <button
                    onClick={() => setHistory([])}
                    className="glass inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold text-muted-foreground transition hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    {t.clearHistory}
                  </button>
                </div>
              </>
            )}
          </Card>
        </section>

        {/* Food Tracker */}
        <section className="mt-8">
          <Card icon={<Apple className="h-5 w-5" />} title={t.tracking} desc={t.trackingDesc}>
            <div
              key={shakeKey}
              className={`grid gap-3 sm:grid-cols-[1fr_140px_auto] ${foodErr ? "animate-shake" : ""}`}
            >
              <input
                type="text"
                placeholder={t.foodName}
                value={foodName}
                maxLength={60}
                onChange={(e) => {
                  setFoodName(e.target.value);
                  if (foodErr === "name") setFoodErr(null);
                }}
                onKeyDown={(e) => e.key === "Enter" && addFood()}
                aria-invalid={foodErr === "name"}
                className={`glass rounded-xl bg-transparent px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/50 ${
                  foodErr === "name" ? "ring-2 ring-destructive/60" : ""
                }`}
              />
              <input
                type="number"
                inputMode="numeric"
                min={1}
                max={5000}
                step={1}
                placeholder={t.calories}
                value={foodCal}
                onChange={(e) => {
                  setFoodCal(e.target.value);
                  if (foodErr === "cal") setFoodErr(null);
                }}
                onKeyDown={(e) => e.key === "Enter" && addFood()}
                aria-invalid={foodErr === "cal"}
                className={`glass rounded-xl bg-transparent px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/50 ${
                  foodErr === "cal" ? "ring-2 ring-destructive/60" : ""
                }`}
              />
              <button
                onClick={addFood}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] hover:opacity-90 hover:shadow-[0_14px_60px_-8px_oklch(0.72_0.18_175/0.7)]"
              >
                <Plus className="h-4 w-4" />
                {t.add}
              </button>
            </div>
            {foodErr && (
              <p className="mt-2 text-sm font-medium text-destructive animate-fade-in" role="alert">
                {foodErr === "name" ? t.errFoodName : t.errCalories}
              </p>
            )}

            {/* Progress */}
            <div className="mt-6">
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {t.consumed}: <span className="font-semibold text-foreground">{consumed}</span> / {result.target} kcal
                </span>
                <span className={`font-semibold ${remaining < 0 ? "text-destructive" : "text-primary"}`}>
                  {t.remaining}: {remaining}
                </span>
              </div>
              <div className="glass h-3 overflow-hidden rounded-full">
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${progressPct}%`,
                    background: "var(--gradient-primary)",
                  }}
                />
              </div>
            </div>

            <div className="mt-6 space-y-2">
              {foods.length === 0 ? (
                <p className="glass rounded-xl p-6 text-center text-sm text-muted-foreground">
                  {t.empty}
                </p>
              ) : (
                foods.map((f) => (
                  <div
                    key={f.id}
                    className="glass animate-pop flex items-center justify-between gap-3 rounded-xl px-4 py-3 hover:-translate-y-0.5"
                  >
                    <span className="min-w-0 flex-1 truncate font-medium">{f.name}</span>
                    <span className="shrink-0 text-sm font-semibold text-primary">
                      {f.calories} kcal
                    </span>
                    <button
                      onClick={() => setFoods((arr) => arr.filter((x) => x.id !== f.id))}
                      className="shrink-0 rounded-lg p-2 text-muted-foreground transition hover:bg-destructive/20 hover:text-destructive"
                      aria-label={t.remove}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </Card>
        </section>

        <footer className="mt-12 pb-6 text-center text-xs text-muted-foreground">
          {t.footer}
        </footer>
      </div>
    </div>
  );
}

function Card({
  icon,
  title,
  desc,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  children: React.ReactNode;
}) {
  return (
    <div className="glass-strong rounded-3xl p-6 sm:p-8">
      <div className="mb-5 flex items-start gap-3">
        <div className="glass grid h-10 w-10 shrink-0 place-items-center rounded-xl text-primary">
          {icon}
        </div>
        <div className="min-w-0">
          <h3 className="text-lg font-bold">{title}</h3>
          {desc && <p className="text-sm text-muted-foreground">{desc}</p>}
        </div>
      </div>
      {children}
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="text-sm font-semibold text-muted-foreground">{children}</label>;
}

function PillButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-xl px-4 py-3 text-sm font-semibold transition ${
        active
          ? "bg-primary text-primary-foreground shadow-[var(--shadow-glow)]"
          : "glass hover:glass-strong"
      }`}
    >
      {children}
    </button>
  );
}

function NumberField({
  label,
  unit,
  value,
  onChange,
  min,
  max,
}: {
  label: string;
  unit: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
}) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <Label>{label}</Label>
        <span className="text-sm font-bold text-primary">
          {value} {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-[oklch(0.78_0.16_160)]"
      />
    </div>
  );
}

function SelectRow({
  active,
  onClick,
  title,
  desc,
}: {
  active: boolean;
  onClick: () => void;
  title: string;
  desc: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-2xl p-4 text-start transition ${
        active
          ? "border border-primary/50 bg-primary/15 shadow-[var(--shadow-glow)]"
          : "glass hover:glass-strong border border-transparent"
      }`}
    >
      <div className="font-semibold">{title}</div>
      <div className="mt-1 text-xs text-muted-foreground">{desc}</div>
    </button>
  );
}

function Stat({
  label,
  value,
  unit,
  highlight,
}: {
  label: string;
  value: number;
  unit: string;
  highlight?: boolean;
}) {
  return (
    <div
      className={`glass rounded-2xl p-5 ${
        highlight ? "border border-primary/40 shadow-[var(--shadow-glow)]" : ""
      }`}
    >
      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className="mt-2 flex items-baseline gap-1">
        <span className={`text-3xl font-extrabold ${highlight ? "text-gradient" : ""}`}>
          {value}
        </span>
        <span className="text-sm text-muted-foreground">{unit}</span>
      </div>
    </div>
  );
}

function MacroBar({
  label,
  grams,
  unit,
  color,
  total,
}: {
  label: string;
  grams: number;
  unit: string;
  color: string;
  total: number;
}) {
  const pct = total > 0 ? (grams / total) * 100 : 0;
  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex items-center justify-between text-sm">
        <span className="font-semibold">{label}</span>
        <span className="font-bold" style={{ color }}>
          {grams} {unit}
        </span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}
